import connexion
from swagger_server.models.me_shngd_response import MeSHNGDResponse
from datetime import date, datetime
from typing import List, Dict
from six import iteritems
from ..util import deserialize_date, deserialize_datetime


def get_pub_med_me_shngd(term1, term2):
    """
    Query to get the Normalized Google Distance between two MeSH terms based on co-occurance in all PubMed article annotations
    
    :param term1: First of two terms. Order not important.
    :type term1: str
    :param term2: Second of two terms. Order not important.
    :type term2: str

    :rtype: MeSHNGDResponse
    """
    return 'do some magic!'
